(function() {
    'use strict';
    angular.module("tickets-mocks",[]);
})();
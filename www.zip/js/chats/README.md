# Concerning Tabs

IF you define a tab under a root like **/tab/chats**, any other link that starts with **/tab/chats** will be also highlighted!

In this example we have:

* /tab/chats
* /tab/chats/whatever/:chat-id
* /tab/chats/a-test

And they all highlight the tab :)

(function() {
    'use strict';
    angular.module("my-tickets",[]);
})();